package io.project.Seller.Repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import io.project.Seller.Pojo.SellerPojo;

@Repository
public interface SellerRepository extends MongoRepository<SellerPojo, String>{

}
