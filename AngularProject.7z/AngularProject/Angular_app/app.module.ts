
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LayoutModule } from '@angular/cdk/layout';
import { MatToolbarModule, MatButtonModule, MatSidenavModule, MatIconModule, MatListModule, MatMenu, MatMenuModule } from '@angular/material';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { FoodListComponent } from './food-list/food-list.component';
import { SellerComponent } from './seller/seller.component';
import { PaymentDetailsComponent } from './payment-details/payment-details.component';
import { ConfirmOrderComponent } from './confirm-order/confirm-order.component';
import { TrackOrderComponent } from './track-order/track-order.component';
import { SideComponent } from './side/side.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { AuthGuard } from './auth.guard';
import { CarouselModule } from 'ngx-bootstrap/carousel';
import { SellerlistComponent } from './sellerlist/sellerlist.component';
import { MyorderComponent } from './myorder/myorder.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { AdminRegisterComponent } from './admin-register/admin-register.component';
import { AdminfoodlistComponent } from './adminfoodlist/adminfoodlist.component';
import { SellregisterComponent } from './sellregister/sellregister.component';
import { SellloginComponent } from './selllogin/selllogin.component';
import { AdminComponent } from './admin/admin.component';



@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
   LoginComponent,     
   RegisterComponent,
    FoodListComponent,
   SellerComponent,
   PaymentDetailsComponent,
   ConfirmOrderComponent,
  TrackOrderComponent,
  SideComponent,
  SellerlistComponent,
  MyorderComponent,
  AdminloginComponent,
  AdminRegisterComponent,
  AdminfoodlistComponent,
  SellregisterComponent,
  SellloginComponent,
  AdminComponent
   
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    LayoutModule,
    MatToolbarModule,
    MatButtonModule,
    MatSidenavModule,
    MatIconModule,
    MatListModule,
    MatMenuModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    
    RouterModule.forRoot( [
      { 
        path: 'home', 
        component: HomeComponent
      },
      
      { 
        path: 'login',
        component: LoginComponent
      },
      { 
        path: 'register',
        component: RegisterComponent
      },
      {
        path:'selllogin',
        component: SellloginComponent
      },
      {
        path: 'food',
        component: FoodListComponent
      },
      {
        path:'sellregis',
        component:SellregisterComponent
      },
      {
        path:'seller',
        component:SellerComponent,
        canActivate:[AuthGuard]
      },
      {
        path:'payment',
        component:PaymentDetailsComponent,
        canActivate:[AuthGuard]
      },
      {
        path:'adminlogin',
        component:AdminloginComponent
      },
      {
        path:'admin',
        component:AdminComponent
   
      },
      {
        path:'adminregis',
        component:AdminRegisterComponent
      },
      {
        path:'adminsell',
        component:AdminfoodlistComponent
      },
      {
        path:'confirm',
        component:ConfirmOrderComponent,
        canActivate:[AuthGuard]
      },
      {
        path:'track',
        component:TrackOrderComponent
      },
      
      {
        path:'sell',
        component:SellerlistComponent
      },
      {
        path:'order',
        component:MyorderComponent,
        canActivate:[AuthGuard]
      },
      {
        path:'**',
        redirectTo:'home'
      }
      ]),
    
    CarouselModule.forRoot(),
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
