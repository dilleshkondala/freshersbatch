import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { PaymentService } from '../payment.service';
import { Router } from '@angular/router';
import { Payment } from '../payment';

@Component({
  selector: 'app-confirm-order',
  templateUrl: './confirm-order.component.html',
  styleUrls: ['./confirm-order.component.css']
})
export class ConfirmOrderComponent implements OnInit {
  regForm: FormGroup;
  address:any;
  constructor(private fb: FormBuilder, private route: Router,private payservice:PaymentService) { }
  payment:Payment=new Payment();
  ngOnInit() {
    this.regForm = this.fb.group({
      address: ['', [Validators.required ]],
    });
  }
  onaddress(){
    this.payment=new Payment();
  }

  onAddress(){
    
    localStorage.setItem('address',this.payment.address);
    
      this.route.navigateByUrl('payment');
  
  }

}
