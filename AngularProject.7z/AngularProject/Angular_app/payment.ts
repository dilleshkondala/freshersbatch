export class Payment
{
    username: string;
	password: string;
    address:string;
    cardnumber:string;
    expdate:string;
    cvv:string;
    cardname:string;
	imageUrl: string;
	price: string;
}