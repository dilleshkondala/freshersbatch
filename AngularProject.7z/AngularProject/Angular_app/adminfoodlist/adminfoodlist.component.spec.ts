import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminfoodlistComponent } from './adminfoodlist.component';

describe('AdminfoodlistComponent', () => {
  let component: AdminfoodlistComponent;
  let fixture: ComponentFixture<AdminfoodlistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminfoodlistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminfoodlistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
