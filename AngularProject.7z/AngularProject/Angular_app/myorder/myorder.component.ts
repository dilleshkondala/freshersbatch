import { Component, OnInit } from '@angular/core';
import { PaymentService } from '../payment.service';
import { Payment } from '../payment';

@Component({
  selector: 'app-myorder',
  templateUrl: './myorder.component.html',
  styleUrls: ['./myorder.component.css']
})
export class MyorderComponent implements OnInit {

  constructor(private bs:PaymentService) { }
  payment:Payment[];
  ngOnInit() {
    this.reloadData();
  }
  reloadData() {
    this.bs.getAll().subscribe(data=>
      {
        this.payment= data as Payment[];
      });
  }
  read(username){
    return localStorage.getItem('username');
  }

}
