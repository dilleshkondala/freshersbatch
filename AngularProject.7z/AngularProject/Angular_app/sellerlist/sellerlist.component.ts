import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SellerService } from '../seller.service';
import { Router } from '@angular/router';
import { Seller } from '../seller';

@Component({
  selector: 'app-sellerlist',
  templateUrl: './sellerlist.component.html',
  styleUrls: ['./sellerlist.component.css']
})
export class SellerlistComponent implements OnInit {
  regForm: FormGroup;
  seller:Seller = new Seller();
  constructor(private fb: FormBuilder, private sellerservice:SellerService,private route:Router) { }

  ngOnInit() {
    this.regForm = this.fb.group({

      imageUrl:['',[Validators.required]],

      price:['',[Validators.required]],

      service:['',[Validators.required]],

      description:['',[Validators.required]]

    });
    
  }
  reg(){
    
    this.seller=new Seller();
    

  }
  
  onSeller(){
    
    const obj={
      username: localStorage.getItem('username'),
      password: localStorage.getItem('password'),
      imageUrl: this.seller.imageUrl,
      service: this.seller.service,
      price: this.seller.price,
      description: this.seller.description
    }
    
    this.sellerservice.addfood(obj).subscribe((data)=>console.log(data),error=>console.error(error));
    
    this.sellerservice.addUser(obj)
      .subscribe((data) =>{
            console.log(data),error=>console.error(error)
            
            this.route.navigateByUrl('seller');
      });
  }

}
