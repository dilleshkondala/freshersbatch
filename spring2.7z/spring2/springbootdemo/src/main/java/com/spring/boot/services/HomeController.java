package com.spring.boot.services;

import org.springframework.stereotype.Controller;

@Controller
public class HomeController {
	
	
	pubic String display() {
		return "Hello World........";
	}

}
