package com.example.demo.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HomeController {
	/*
	 * @RequestMapping("/") public String display() {
	 * System.out.println("Hello World....."); return "home.jsp"; }
	 */
	
	@RequestMapping("/")
	public String messageDisplay() {
		System.out.println("Hello SpringBoot.....");
		return "home";
	}
	

}
