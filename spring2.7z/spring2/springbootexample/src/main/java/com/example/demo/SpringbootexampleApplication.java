package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import org.springframework.context.ConfigurableApplicationContext;

import com.example.demo.pojos.User;

@SpringBootApplication
public class SpringbootexampleApplication {

	public static void main(String[] args) {
		 ConfigurableApplicationContext context = SpringApplication.run(SpringbootexampleApplication.class, args);
		 
		 User user = context.getBean(User.class);
		 user.displayUser();
	 
		
		 
		 
		/*
		 * app.setDefaultProperties(Collections .singletonMap("server.port", "8083"));
		 * app.run(args);
		 */
	}

}
