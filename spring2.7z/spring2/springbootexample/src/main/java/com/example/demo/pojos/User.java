package com.example.demo.pojos;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class User {
	private String uname;
	private int uid;
	@Autowired
	private Laptop laptop;
	
	public User() {
		System.out.println("Object Created.....");
		
	}

	public User(String uname, int uid, Laptop laptop) {
		super();
		this.uname = uname;
		this.uid = uid;
		this.laptop = laptop;
	}

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public int getUid() {
		return uid;
	}

	public void setUid(int uid) {
		this.uid = uid;
	}

	public Laptop getLaptop() {
		return laptop;
	}

	public void setLaptop(Laptop laptop) {
		this.laptop = laptop;
	}

	@Override
	public String toString() {
		return "User [uname=" + uname + ", uid=" + uid + ", laptop=" + laptop + "]";
	}
	
	public void displayUser() {
		System.out.println("User method is printing....");
		laptop.displayLaptop();
	}

	
}
