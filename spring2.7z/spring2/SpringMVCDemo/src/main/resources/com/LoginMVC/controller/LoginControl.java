package com.LoginMVC.controller;

import javax.security.auth.message.callback.PrivateKeyCallback.Request;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

//import prg.


@Controller
@RequestMapping("/")
public class LoginControl {
	
//	@RequestMapping(method=RequestMethod.GET)
//	public ModelAndView loginMethod()
//	{
//		
//		ModelAndView mv = new ModelAndView();
//		mv.addObject("username","hello"+username)
//		return mv;
	}
	
	
	
	@RequestMapping(method=RequestMethod.GET)
	public ModelAndView loginMethod1(@RequestParam("uname") String username, @RequestParam("pswd") String password, 
			//HttpServletRequest request, HttpServletResponseS response)
	{
//		String username = request.getParameter("uname");
//		String password = request.getParameter("pswd");
		
		ModelAndView mv = new ModelAndView();
		mv.setViewName("display");
		mv.addObject("username","hello"+username)
		return mv;
	}

}
